# Practica 1 - Complejidad Computacional

Se puede ejecutar el programa con cada ejemplar con los siguientes comandos:

- 3.1 Ejemplar 3-coloreable

```
$ python src/practica.py ejemplares/ej3-1_3-coloreable.txt
```

- 3.2 Ejemplar 2-coloreable

```
$ python src/practica.py ejemplares/ej3-2_2-coloreable.txt
```

- 3.3 Ejemplar 2-coloreable

```
$ python src/practica.py ejemplares/ej3-3_2-coloreable.txt
```

- 3.4 Ejemplar NO 2-coloreable

```
$ python src/practica.py ejemplares/ej3-4_no_2-coloreable.txt
```
