# Practica 2 - Complejidad Computacional

Se puede ejecutar el programa con cada ejemplar con los siguientes comandos:

- Para generar certificados:

```
$ python src/practica.py generar ejemplares/ej3.txt certificados/ej3_cert1.txt
```

- Para verificar certificados

```
$ python src/practica.py verificar ejemplares/ej3.txt certificados/ej3_cert5.txt
```
